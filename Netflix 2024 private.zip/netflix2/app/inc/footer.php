<footer class="w-100 d-flex justify-content-center py-5 px-4">
    <div class="footw">
<p><?= lang("xfoot1"); ?></p>
<div class="row text-start">
    <span class="col-md-6 col-lg-4"><?= lang("xfoot2"); ?></span>
    <span class="col-md-6 col-lg-4"><?= lang("xfoot3"); ?></span>
    <span class="col-md-6 col-lg-4"><?= lang("xfoot4"); ?></span>
    <span class="col-md-6 col-lg-4"><?= lang("xfoot5"); ?></span>
    <span class="col-md-6 col-lg-4"><?= lang("xfoot6"); ?></span>
    <span class="col-md-6 col-lg-4"><?= lang("xfoot7"); ?></span>
</div>
<div class="p-2 my-3 footlng d-flex flex-row justify-content-between align-items-center">
    <img style="width: 25px;" src="assets/images/footerlng.png" alt="" srcset="">
    <span><?= lang("xfoot8"); ?></span>
    <img src="assets/images/footerrow.png" alt="" srcset="">
</div>
    </div>
</footer>